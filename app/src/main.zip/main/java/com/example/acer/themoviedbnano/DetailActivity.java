package com.example.acer.themoviedbnano;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class DetailActivity extends AppCompatActivity {
    TextView t1,t2,t3,t4;
    ImageView i1;
    String trailer_url1="http://api.themoviedb.org/3/movie/" ;
       String getTrailer_url12=     "/videos?api_key=2102fede37aef6e84e37cf5bdd0b80aa";
    String mid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        t1=findViewById(R.id.detailtext1);
        t2=findViewById(R.id.detailtext2);
        t3=findViewById(R.id.detailtext3);
        t4=findViewById(R.id.tlink);
        i1=findViewById(R.id.detailimg);
        String[] s=getIntent().getStringArrayExtra("mydata");
        t1.setText(s[0]);
        Picasso.with(this).load("https://image.tmdb.org/t/p/w500"+s[3]).placeholder(R.mipmap.ic_launcher_round).into(i1);
        t2.setText(s[1]);
        t3.append(s[2]);
        mid=s[4];
        new TrailerAsync().execute();






    }
    public class TrailerAsync extends AsyncTask<String,Void,String>
    {


        @Override
        protected String doInBackground(String... strings) {
            try {
                URL urlstring=new URL(trailer_url1+mid+getTrailer_url12);
                HttpURLConnection httpURLConnection= (HttpURLConnection) urlstring.openConnection();
                httpURLConnection.connect();
                InputStream inputStream= httpURLConnection.getInputStream();
                Scanner s=new Scanner(inputStream);
                s.useDelimiter("\\A");
                if(s.hasNext())
                {
                    return s.next();
                }
                else return null;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONObject jsonObject=new JSONObject(s);
                JSONArray results=jsonObject.getJSONArray("results");
                JSONObject firstObject=results.getJSONObject(1);
                final String MovieId=firstObject.getString("id");
                t4.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intent = new Intent(Intent.ACTION_VIEW,
                                Uri.parse("http://www.youtube.com/watch?v=" + MovieId));
                        startActivity(intent);
                    }
                });

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }




}
